var leaveDate = /[0-9]{4}\/[0-9]{2}\/[0-9]{2}$/;


$("#leave-button").click(function () {
    var temp = $("#leave-date").val();
    if(temp !== ""){
        $.post("add-leave", $("#add-leave-form").serialize(), function (response) {
            alert(response);
        });
    }else{
        $("#leave-date").focus();
    }
});

