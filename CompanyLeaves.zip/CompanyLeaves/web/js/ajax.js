
var regisName = /^[a-zA-Z]+$|^([a-zA-Z]+\s[a-zA-Z]+)+$/;
var regisAddress = /^[a-zA-Z]+$|^([a-zA-Z]+\s[a-zA-Z]+)+$/;
var regisNumber = /^\d{10}$/;
var regisMail = /^([a-zA-Z]+|^([a-zA-Z]+\d+)+|^([a-zA-Z]+\d+[a-zA-Z]+)+)\@gmail\.com$/;
var regisPassword = /^[a-zA-Z]+|\d+|\D+|s\|\S$/;


function SelectPosition() {
    $("#warining").html("");
    $.getJSON("get-status-respond", $("#sign-position-one").serialize(), function (response) {
        if (response.position) {
            var postionObject = response.data;
            var html = "<div class=\"form-group\" ><label  class=\"col-sm-3 control-label\">Position</label>  <div class=\"col-sm-9\"><select class=\"form-control\" name=\"sign-position-two\" >";
            for (var i = 0; i < postionObject.length; i++) {
                html += "<option value=\"" + postionObject[i].id + "\">" + postionObject[i].name + "</option>"
            }
            html += "</select></div></div>";

            $("#sign-position").html(html);
        } else {
            $("#sign-position").html("");
        }
    });
}
;



$("#sign-name").keypress(function () {
    if (event.keyCode == 13) {
        var temp = $(this).val();
        if (regisName.test(temp)) {
            $("#sign-mail").focus();
        } else {
            $("#sign-form-name").addClass("has-error").val("");
        }
    } else {
        $("#sign-form-name").removeClass("has-error");
    }
});

$("#sign-mail").keypress(function () {
    if (event.keyCode == 13) {
        var temp = $(this).val();
        if (regisMail.test(temp)) {
            $("#sign-password").focus();
        } else {
            $("#sign-form-mail").addClass("has-error").val("");
        }
    } else {
        $("#sign-form-mail").removeClass("has-error");
    }
});

$("#sign-password").keypress(function () {
    if (event.keyCode == 13) {
        var temp = $(this).val();
        if (regisPassword.test(temp)) {
            $("#conformPassword").focus();
        } else {
            $("#sign-form-new-password").addClass("has-error").val("");
        }
    } else {
        $("#sign-form-new-password").removeClass("has-error");
    }
});

$("#conformPassword").keypress(function () {
    if (event.keyCode == 13) {
        if ($(this).val() === $("#sign-password").val()) {
            $("#sign-phone-num").focus();
        } else {
            $("#sign-form-confrom-password").addClass("has-error").val();
        }
    } else {
        $("#sign-form-confrom-password").removeClass("has-error");
    }
});

$("#sign-phone-num").keypress(function () {
    if (event.keyCode == 13) {
        var temp = $(this).val();
        if (regisNumber.test(temp)) {
            $("#sign-button2").focus();
        } else {
            $("#sign-form-num").addClass("has-error").val("");
        }
    } else {
        $("#sign-form-num").removeClass("has-error");
    }
});


$("#sign-button2").click(function () {
    var isTrue = true;
    {
        if (!(regisNumber.test($("#sign-phone-num").val()))) {
            $("#sign-form-num").addClass("has-error");
            $("#sign-phone-num").focus();
            isTrue = false;
        }
        if (!(regisPassword.test($("#conformPassword").val()))) {
            $("#sign-form-confrom-password").addClass("has-error");
            $("#conformPassword").focus();
        }

        if (!(regisPassword.test($("#sign-password").val()))) {
            $("#sign-form-new-password").addClass("has-error");
            $("#sign-password").focus();
        }
        if (!(regisMail.test($("#sign-mail").val()))) {
            $("#sign-form-mail").addClass("has-error");
            $("#sign-mail").focus();
            isTrue = false;
        }
        if (!(regisName.test($("#sign-name").val()))) {
            $("#sign-form-name").addClass("has-error");
            $("#sign-name").focus();
            isTrue = false;
        }
        if (!($("#conformPassword").val() === $("#sign-password").val())) {
            $("#sign-form-confrom-password").addClass("has-error").val("");
            $("#conformPassword").focus();
            isTrue = false;
        }
    }
    if (isTrue) {
        $.post("sign-up", $("#sign-up").serialize(), function (response) {
            var res = response.status;

            if (res == false) {
                alert("No");
            }
            if (res === undefined) {
                $("body").html(response);
            }

        });
    }
});
/*
 * <label  class="col-sm-3 control-label">Position</label> 
 <div class="col-sm-9">
 <select class="form-control" name="sign-position-one" id="sign-position-one" onchange="SelectPosition()">
 <option value="1">Manager</option>
 <option value="2">Department head</option>
 <option value="3">Employee</option>
 </select>
 </div>
 */

$("#leave-button").click(function () {
    alert("sdsdsd");

//    $.post("add-leave", $("#add-leave-form").serialize(), function (response) {
//        alert(response);
//    });
});
//
//$("#sign-button2").click(function () {
//    $.post("sign-up", $("#sign-up").serialize(), function (response) {
//        var res = response.status;
//
//        if (res == false) {
//            alert("No");
//        }
//        if (res === undefined) {
//            $("body").html(response);
//        }
//
//    });
//});



