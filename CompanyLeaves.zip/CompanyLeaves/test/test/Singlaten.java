package test;

import ijse.sun.companyleaves.application.factory.DAOFactory;
import ijse.sun.companyleaves.application.factory.impl.DAOFactoryImpl;
import ijse.sun.companyleaves.wrappers.ServletContextWrapper;
import javax.servlet.ServletContext;

public class Singlaten {
    
    
    private DAOFactory aOFactory = new DAOFactoryImpl(null);
    
    public void temp(){
        //aOFactory.
    }
    
}
