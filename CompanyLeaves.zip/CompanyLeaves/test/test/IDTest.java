package test;

import java.lang.reflect.Array;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collection;
import java.util.Collections;
import java.util.Date;
import java.util.List;

public class IDTest {
    public static void main(String[] args) {
        Date date = new Date();
        
        SimpleDateFormat formats = new SimpleDateFormat("dd/mm/yyy");
        
        String n =formats.format(date);
        
        System.err.println(n);
    }
}
