package ijse.sun.companyleaves.application.impl;

import ijse.sun.companyleaves.attributes.ApplicationAttribute;
import ijse.sun.companyleaves.common.dto.Department;
import ijse.sun.companyleaves.application.DepartmentDAO;
import ijse.sun.companyleaves.wrappers.ServletContextWrapper;
import java.util.ArrayList;
import javax.servlet.ServletContext;

public class DepartmentDAOImpl implements DepartmentDAO {

    private ServletContext servletContext;

    public DepartmentDAOImpl(ServletContext servletContext) {
        this.servletContext = servletContext;
    }

    @Override
    public ArrayList<Department> getAllDepartments() {
        ArrayList<Department> departments = (ArrayList<Department>) servletContext.getAttribute(ApplicationAttribute.DEPARTMENT_SCOPE);
         return departments;
    }

    @Override
    public Department searchDepartment(String departId) {
        ArrayList<Department> departmentList = (ArrayList<Department>) servletContext.getAttribute(ApplicationAttribute.DEPARTMENT_SCOPE);

        for (Department department1 : departmentList) {
            if (department1.getId().equals(departId)) {
                return department1;
            }
        }

        return null;
    }

}
