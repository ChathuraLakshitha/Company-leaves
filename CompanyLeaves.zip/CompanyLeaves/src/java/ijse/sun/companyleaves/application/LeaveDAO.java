package ijse.sun.companyleaves.application;

import ijse.sun.companyleaves.common.dto.Leave;
import java.util.ArrayList;

public interface LeaveDAO {

    Leave searchLeave(String leaveID);

    ArrayList<Leave> getAllLeaves();

    ArrayList<Leave> getDepartmentLeave(String departentId);

    ArrayList<Leave> getDepartmentAcceptedLeave(String departentId);

    ArrayList<Leave> getManagerLeave();

    ArrayList<Leave> getManagerAcceptedLeave();

    Leave addLeave(Leave leave);

}
