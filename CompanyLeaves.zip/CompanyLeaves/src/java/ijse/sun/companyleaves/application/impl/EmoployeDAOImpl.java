package ijse.sun.companyleaves.application.impl;

import ijse.sun.companyleaves.attributes.ApplicationAttribute;
import ijse.sun.companyleaves.attributes.SessionAttribute;
import ijse.sun.companyleaves.common.dto.Employee;
import ijse.sun.companyleaves.application.EmployeeDAO;
import ijse.sun.companyleaves.idgenerator.IDGenerator;
import ijse.sun.companyleaves.wrappers.ServletContextWrapper;
import java.util.ArrayList;
import java.util.List;
import javax.servlet.RequestDispatcher;
import javax.servlet.ServletContext;
import javax.servlet.http.HttpServletRequest;

public class EmoployeDAOImpl implements EmployeeDAO {

    private ServletContext contextWrapper;

    public EmoployeDAOImpl(ServletContext servletContext) {
        this.contextWrapper = servletContext;
    }

    @Override
    public Employee addEmployee(HttpServletRequest request) {

        String name = request.getParameter("sign-name");
        String mail = request.getParameter("sign-mail");
        String password = request.getParameter("sign-password");
        String gender = request.getParameter("sign-gender");
        int phoneNumber = Integer.parseInt(request.getParameter("sign-phone-num"));
        String departmentID = request.getParameter("sign-position-two");

        IDGenerator iDGenerator = new IDGenerator((ServletContext) contextWrapper);

        String empId = iDGenerator.createEmployeeId();

        Employee employee = new Employee(empId, departmentID, name, mail, password, phoneNumber, gender);
        
        System.out.println(empId+" : "+departmentID+" : "+ name+" : "+ mail+" : "+password+" : "+phoneNumber+" : "+gender);

        ArrayList<Employee> employeesList = (ArrayList<Employee>) contextWrapper.getAttribute(ApplicationAttribute.EMPLOYEE_SCOPE);

        employeesList.add(employee);
        
        contextWrapper.removeAttribute(ApplicationAttribute.EMPLOYEE_SCOPE);
        contextWrapper.setAttribute(ApplicationAttribute.EMPLOYEE_SCOPE, employeesList);
        request.getSession().setAttribute(SessionAttribute.USER_ID, employee.getEmpId());
        return employee;

    }

    @Override
    public List<Employee> getAllEmployees() {
        ArrayList<Employee> employees = (ArrayList<Employee>) this.contextWrapper.getAttribute(ApplicationAttribute.EMPLOYEE_SCOPE);
        return employees;
    }

    @Override
    public Employee searchEmployee(String empId) {
        empId.trim();

        ArrayList<Employee> employees = (ArrayList<Employee>) this.contextWrapper.getAttribute(ApplicationAttribute.EMPLOYEE_SCOPE);

        if (employees.isEmpty()) {
            return null;
        } else {
            for (Employee employee : employees) {
                if (employee.getEmpId().equals(empId)) {
                    return employee;
                }
            }
        }
        return null;
    }

    @Override
    public Employee searchEmployeeToLogin(String mail, String password) {
        ArrayList<Employee> employees = (ArrayList<Employee>) this.contextWrapper.getAttribute(ApplicationAttribute.EMPLOYEE_SCOPE);

        if (employees.isEmpty()) {
            return null;
        } else {
            for (Employee employee : employees) {
                if (employee.getMail().equalsIgnoreCase(mail) && employee.getPassword().equals(password)) {
                    return employee;
                }
            }
        }
        return null;
    }

    @Override
    public Employee searchEmployeeToLogin(String mail) {
        ArrayList<Employee> employees = (ArrayList<Employee>) this.contextWrapper.getAttribute(ApplicationAttribute.EMPLOYEE_SCOPE);

        if (employees.isEmpty()) {
            return null;
        } else {
            for (Employee employee : employees) {
                if (employee.getMail().equalsIgnoreCase(mail)) {
                    return employee;
                }
            }
        }
        return null;
    }

}
