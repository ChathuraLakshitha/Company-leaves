package ijse.sun.companyleaves.application;

import ijse.sun.companyleaves.common.dto.DepartmentHead;
import java.util.List;
import javax.servlet.http.HttpServletRequest;

public interface DepartmentHeadDAO {

    DepartmentHead addDepartmentHead(HttpServletRequest request);

    List<DepartmentHead> getAllDepartmentHeads();

    DepartmentHead searchDepartmentHead(String departmentHeadId);

    DepartmentHead searchDepartHeatToLogin(String mail, String password);

    DepartmentHead searchDepartHeatToLogin(String mial);
    
    DepartmentHead searchDeaparByDepartmnet(String departmentId);

}
