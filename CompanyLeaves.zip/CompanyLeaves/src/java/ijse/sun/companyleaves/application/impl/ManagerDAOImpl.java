package ijse.sun.companyleaves.application.impl;

import ijse.sun.companyleaves.attributes.ApplicationAttribute;
import ijse.sun.companyleaves.attributes.SessionAttribute;
import ijse.sun.companyleaves.common.dto.Manager;
import ijse.sun.companyleaves.application.ManagerDAO;
import ijse.sun.companyleaves.idgenerator.IDGenerator;
import ijse.sun.companyleaves.wrappers.ServletContextWrapper;
import java.util.List;
import javax.servlet.ServletContext;
import javax.servlet.http.HttpServletRequest;

public class ManagerDAOImpl implements ManagerDAO {

    private ServletContext contextWrapper;

    public ManagerDAOImpl(ServletContext servletContext) {
        this.contextWrapper = servletContext;
    }

    @Override
    public Manager addManager(HttpServletRequest request) {
        String name = request.getParameter("sign-name");
        String mail = request.getParameter("sign-mail");
        String password = request.getParameter("sign-password");
        String gender = request.getParameter("sign-gender");
        int phoneNumber = Integer.parseInt(request.getParameter("sign-phone-num"));

        IDGenerator iDGenerator = new IDGenerator(contextWrapper);

        String id = iDGenerator.createManagerId();

        Manager manager = new Manager(id, name, mail, gender, password, phoneNumber);

        contextWrapper.setAttribute(ApplicationAttribute.MANAGER_SCOPE, manager);
        request.getSession().setAttribute(SessionAttribute.USER_ID, manager.getHeadId());
        return manager;
    }

    @Override
    public Manager getManager() {
        Manager manager = (Manager) contextWrapper.getAttribute(ApplicationAttribute.MANAGER_SCOPE);
        return manager;
    }

}
