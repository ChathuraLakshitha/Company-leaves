package ijse.sun.companyleaves.application.impl;

import ijse.sun.companyleaves.attributes.ApplicationAttribute;
import ijse.sun.companyleaves.attributes.SessionAttribute;
import ijse.sun.companyleaves.common.dto.DepartmentHead;
import ijse.sun.companyleaves.application.DepartmentHeadDAO;
import ijse.sun.companyleaves.idgenerator.IDGenerator;
import ijse.sun.companyleaves.wrappers.ServletContextWrapper;
import java.util.ArrayList;
import java.util.List;
import javax.servlet.ServletContext;
import javax.servlet.http.HttpServletRequest;

public class DepartmentHeadDAOImpl implements DepartmentHeadDAO {

    private ServletContext contextWrapper;

    public DepartmentHeadDAOImpl(ServletContext servletContext) {
        this.contextWrapper = servletContext;
    }

    @Override
    public DepartmentHead addDepartmentHead(HttpServletRequest request) {
        IDGenerator iDGenerator = new IDGenerator(contextWrapper);
        String name = request.getParameter("sign-name");
        String departId = request.getParameter("sign-position-two");
        String deHeadId = iDGenerator.createDepartmentHeadId(departId);
        int phoneNum = Integer.parseInt(request.getParameter("sign-phone-num"));
        String gender = request.getParameter("sign-gender");
        String mail = request.getParameter("sign-mail");
        String password = request.getParameter("sign-password");

        if (deHeadId == null) {
            return null;
        } else {
            DepartmentHead departmentHead = new DepartmentHead(deHeadId, departId, name, mail, gender, password, phoneNum);
            ArrayList<DepartmentHead> departmentHeadsList = (ArrayList<DepartmentHead>) getAllDepartmentHeads();
            departmentHeadsList.add(departmentHead);
            contextWrapper.setAttribute(ApplicationAttribute.DEPARTMENT_HEAD_SCOPE, departmentHeadsList);
            request.getSession().setAttribute(SessionAttribute.USER_ID, departmentHead.getHeadId());
            return departmentHead;
        }

    }

    @Override
    public List<DepartmentHead> getAllDepartmentHeads() {
        ArrayList<DepartmentHead> departmentHeadLIst = (ArrayList<DepartmentHead>) contextWrapper.getAttribute(ApplicationAttribute.DEPARTMENT_HEAD_SCOPE);
        return departmentHeadLIst;
    }

    @Override
    public DepartmentHead searchDepartmentHead(String departmentHeadId) {
        ArrayList<DepartmentHead> departmentHeadLIst = (ArrayList<DepartmentHead>) contextWrapper.getAttribute(ApplicationAttribute.DEPARTMENT_HEAD_SCOPE);

        for (DepartmentHead departmentHead : departmentHeadLIst) {
            if (departmentHead.getHeadId().equals(departmentHeadId)) {
                return departmentHead;
            }
        }

        return null;
    }

    @Override
    public DepartmentHead searchDepartHeatToLogin(String mail, String password) {
        ArrayList<DepartmentHead> departmentHeadLIst = (ArrayList<DepartmentHead>) contextWrapper.getAttribute(ApplicationAttribute.DEPARTMENT_HEAD_SCOPE);

        if (departmentHeadLIst.isEmpty()) {
            return null;
        } else {
            for (DepartmentHead departmentHead : departmentHeadLIst) {
                if (departmentHead.getMail().equalsIgnoreCase(mail) && departmentHead.getPassword().equals(password)) {
                    return departmentHead;
                }
            }
        }
        return null;
    }

    @Override
    public DepartmentHead searchDepartHeatToLogin(String mail) {
        ArrayList<DepartmentHead> departmentHeadLIst = (ArrayList<DepartmentHead>) contextWrapper.getAttribute(ApplicationAttribute.DEPARTMENT_HEAD_SCOPE);

        if (departmentHeadLIst.isEmpty()) {
            return null;
        } else {
            for (DepartmentHead departmentHead : departmentHeadLIst) {
                if (departmentHead.getMail().equalsIgnoreCase(mail)) {
                    return departmentHead;
                }
            }
        }
        return null;
    }

    @Override
    public DepartmentHead searchDeaparByDepartmnet(String departmentId) {
        ArrayList<DepartmentHead> departmentHeadsList = (ArrayList<DepartmentHead>) getAllDepartmentHeads();

        for (DepartmentHead departmentHead : departmentHeadsList) {
            if (departmentHead.getDepartmentId().equals(departmentId)) {
                return departmentHead;
            }
        }
        return null;
    }
}
