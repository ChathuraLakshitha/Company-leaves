package ijse.sun.companyleaves.application.impl;

import ijse.sun.companyleaves.application.EmployeeDAO;
import ijse.sun.companyleaves.attributes.ApplicationAttribute;
import ijse.sun.companyleaves.attributes.SessionAttribute;
import ijse.sun.companyleaves.common.dto.DepartmentHead;
import ijse.sun.companyleaves.common.dto.Leave;
import ijse.sun.companyleaves.application.LeaveDAO;
import ijse.sun.companyleaves.application.factory.DAOFactory;
import ijse.sun.companyleaves.application.factory.impl.DAOFactoryImpl;
import java.util.ArrayList;
import javax.servlet.ServletContext;

public class LeaveDAOImpl implements LeaveDAO {

    private ServletContext servletContext;

    public LeaveDAOImpl(ServletContext servletContext) {
        this.servletContext = servletContext;
    }

    @Override
    public Leave searchLeave(String leaveID) {
        ArrayList<Leave> leaveList = (ArrayList<Leave>) servletContext.getAttribute(ApplicationAttribute.LEAVE_SCOPE);

        if (leaveList.isEmpty()) {
            return null;
        } else {
            for (Leave leave : leaveList) {
                if (leave.getLeaveId().equalsIgnoreCase(leaveID)) {
                    return leave;
                }
            }

            return null;
        }
    }

    @Override
    public ArrayList<Leave> getAllLeaves() {
        ArrayList<Leave> leaveList = (ArrayList<Leave>) servletContext.getAttribute(ApplicationAttribute.LEAVE_SCOPE);
        return leaveList;
    }

    @Override
    public ArrayList<Leave> getDepartmentLeave(String departentId) {
        ArrayList<Leave> leaveList = (ArrayList<Leave>) servletContext.getAttribute(ApplicationAttribute.LEAVE_SCOPE);

        DAOFactory dAOFactory = new DAOFactoryImpl(servletContext);

        String departmentId = dAOFactory.createDepartmentHeadDAO().searchDepartmentHead(departentId).getDepartmentId();

        EmployeeDAO empDAO = dAOFactory.createEmployeeDAO();

        ArrayList<Leave> departLeaves = new ArrayList<Leave>();

        for (Leave leave : leaveList) {
            if (leave.getDepartmentId().equals(departmentId) && (leave.getStatus() == 0)) {
                //String emName = empDAO.searchEmployee(leave.getEmptId()).getName();
                //leave.setEmptId(emName);
                departLeaves.add(leave);
            }
        }
        return departLeaves;
    }

    @Override
    public ArrayList<Leave> getManagerLeave() {
        ArrayList<Leave> leaveList = (ArrayList<Leave>) servletContext.getAttribute(ApplicationAttribute.LEAVE_SCOPE);

        ArrayList<Leave> departLeaves = new ArrayList<Leave>();

        DAOFactory dAOFactory = new DAOFactoryImpl(servletContext);

        EmployeeDAO empDAO = dAOFactory.createEmployeeDAO();

        for (Leave leave : leaveList) {
            if ((leave.getStatus() == 1)) {
                departLeaves.add(leave);
            }
        }

        return departLeaves;
    }

    @Override
    public ArrayList<Leave> getDepartmentAcceptedLeave(String departentId) {
        ArrayList<Leave> leaveList = (ArrayList<Leave>) servletContext.getAttribute(ApplicationAttribute.LEAVE_SCOPE);

        DAOFactory dAOFactory = new DAOFactoryImpl(servletContext);

        EmployeeDAO empDAO = dAOFactory.createEmployeeDAO();

        String departmentId = dAOFactory.createDepartmentHeadDAO().searchDepartmentHead(departentId).getDepartmentId();

        ArrayList<Leave> departLeaves = new ArrayList<Leave>();

        for (Leave leave : leaveList) {
            if (leave.getEmptId() != departentId) {
                if (leave.getDepartmentId().equals(departmentId) && (leave.getStatus() == 1)) {
                   // String emName = empDAO.searchEmployee(leave.getEmptId()).getName();
                   // leave.setEmptId(emName);
                    departLeaves.add(leave);
                }
            }
        }
        return departLeaves;
    }

    @Override
    public ArrayList<Leave> getManagerAcceptedLeave() {
        ArrayList<Leave> leaveList = (ArrayList<Leave>) servletContext.getAttribute(ApplicationAttribute.LEAVE_SCOPE);

        ArrayList<Leave> departLeaves = new ArrayList<Leave>();

        for (Leave leave : leaveList) {
            if ((leave.getStatus() == 2)) {
                departLeaves.add(leave);
            }
        }

        return departLeaves;
    }

    @Override
    public Leave addLeave(Leave leave) {
        ArrayList<Leave> leaveList = (ArrayList<Leave>) servletContext.getAttribute(ApplicationAttribute.LEAVE_SCOPE);
        leaveList.add(leave);
        servletContext.setAttribute(ApplicationAttribute.LEAVE_SCOPE, leaveList);

        return leave;
    }

}
