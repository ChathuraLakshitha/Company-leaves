package ijse.sun.companyleaves.application.factory.impl;

import ijse.sun.companyleaves.common.dto.Department;
import ijse.sun.companyleaves.application.DepartmentDAO;
import ijse.sun.companyleaves.application.DepartmentHeadDAO;
import ijse.sun.companyleaves.application.EmployeeDAO;
import ijse.sun.companyleaves.application.LeaveDAO;
import ijse.sun.companyleaves.application.ManagerDAO;
import ijse.sun.companyleaves.application.factory.DAOFactory;
import ijse.sun.companyleaves.application.impl.DepartmentDAOImpl;
import ijse.sun.companyleaves.application.impl.DepartmentHeadDAOImpl;
import ijse.sun.companyleaves.application.impl.EmoployeDAOImpl;
import ijse.sun.companyleaves.application.impl.LeaveDAOImpl;
import ijse.sun.companyleaves.application.impl.ManagerDAOImpl;
import ijse.sun.companyleaves.wrappers.ServletContextWrapper;
import javax.servlet.ServletContext;

public class DAOFactoryImpl implements DAOFactory {

    private ServletContext contextWrapper;

    public DAOFactoryImpl(ServletContext servletContext) {
        this.contextWrapper = servletContext;
    }

    @Override
    public DepartmentHeadDAO createDepartmentHeadDAO() {
        DepartmentHeadDAO departmentHeadDAO = new DepartmentHeadDAOImpl(contextWrapper);
        return departmentHeadDAO;
    }

    @Override
    public EmployeeDAO createEmployeeDAO() {
        EmployeeDAO employeeDAO = new EmoployeDAOImpl(contextWrapper);
        return employeeDAO;
    }

    @Override
    public ManagerDAO createManagerDAO() {
        ManagerDAO managerDAO = new ManagerDAOImpl(contextWrapper);
        return managerDAO;
    }

    @Override
    public DepartmentDAO createDepartment() {
        DepartmentDAO departmentDAO = new DepartmentDAOImpl(contextWrapper);

        return departmentDAO;
    }

    @Override
    public LeaveDAO createLeaveDAO() {
        LeaveDAO leaveDAO = new LeaveDAOImpl(contextWrapper);

        return leaveDAO;
    }

}
