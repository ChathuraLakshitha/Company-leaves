package ijse.sun.companyleaves.application;

import ijse.sun.companyleaves.common.dto.Manager;
import java.util.List;
import javax.servlet.http.HttpServletRequest;

public interface ManagerDAO {

    Manager addManager(HttpServletRequest request);

    Manager getManager();

}
