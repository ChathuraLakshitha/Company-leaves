package ijse.sun.companyleaves.application;

import ijse.sun.companyleaves.common.dto.Employee;
import java.util.List;
import javax.servlet.http.HttpServletRequest;

public interface EmployeeDAO {

    Employee addEmployee(HttpServletRequest httpServletRequest);

    List<Employee> getAllEmployees();

    Employee searchEmployee(String empId);

    Employee searchEmployeeToLogin(String mail, String password);

    Employee searchEmployeeToLogin(String mail);
}
