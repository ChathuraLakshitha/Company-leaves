package ijse.sun.companyleaves.application;

import ijse.sun.companyleaves.common.dto.Department;
import java.util.ArrayList;

public interface DepartmentDAO {
        ArrayList<Department> getAllDepartments();
        
        Department searchDepartment(String departId);
}
