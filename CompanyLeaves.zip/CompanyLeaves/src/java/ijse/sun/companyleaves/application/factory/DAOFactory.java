package ijse.sun.companyleaves.application.factory;

import ijse.sun.companyleaves.common.dto.Department;
import ijse.sun.companyleaves.application.DepartmentDAO;
import ijse.sun.companyleaves.application.DepartmentHeadDAO;
import ijse.sun.companyleaves.application.EmployeeDAO;
import ijse.sun.companyleaves.application.LeaveDAO;
import ijse.sun.companyleaves.application.ManagerDAO;

public interface DAOFactory {
    DepartmentHeadDAO createDepartmentHeadDAO();

    EmployeeDAO createEmployeeDAO();

    ManagerDAO createManagerDAO();
    
    DepartmentDAO createDepartment();
    
    LeaveDAO createLeaveDAO();
}
