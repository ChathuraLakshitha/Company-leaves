package ijse.sun.companyleaves.idgenerator;

import com.sun.org.apache.bcel.internal.generic.AALOAD;
import ijse.sun.companyleaves.common.dto.Department;
import ijse.sun.companyleaves.common.dto.Employee;
import ijse.sun.companyleaves.common.dto.Leave;
import ijse.sun.companyleaves.common.dto.Manager;
import ijse.sun.companyleaves.application.factory.DAOFactory;
import ijse.sun.companyleaves.application.factory.impl.DAOFactoryImpl;
import java.awt.List;
import java.lang.reflect.Array;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collections;
import javax.servlet.ServletContext;

public class IDGenerator {

    private DAOFactory dAOFactory;

    public IDGenerator(ServletContext servletContext) {
        this.dAOFactory = new DAOFactoryImpl(servletContext);
    }

    public final String createEmployeeId() {
        ArrayList<Employee> emplist = (ArrayList<Employee>) this.dAOFactory.createEmployeeDAO().getAllEmployees();
        if (emplist.isEmpty()) {
            return "EMP001";
        } else {
            ArrayList<Integer> tempList = new ArrayList<Integer>();
            for (Employee employee : emplist) {
                tempList.add(Integer.parseInt(employee.getEmpId().split("[a-zA-Z]+")[1]));
            }

            Collections.sort(tempList);

            int id = tempList.get((tempList.size() - 1));

            return "EMP00" + ++id;
        }
    }

    public final String createManagerId() {
        return "MAN001";
    }

    public final String createDepartmentHeadId(String departmentID) {
        Department department = dAOFactory.createDepartment().searchDepartment(departmentID);

        if (department == null) {
            return null;
        } else {
            return department.getId();
        }
    }

    public final String createLeaveId() {
        ArrayList<Leave> leaveList = dAOFactory.createLeaveDAO().getAllLeaves();

        if (leaveList.isEmpty()) {
            return "LEAV001";
        } else {
            ArrayList<Integer> tempList = new ArrayList<Integer>();
            for (Leave leave : leaveList) {
                tempList.add(Integer.parseInt(leave.getLeaveId().split("[a-zA-Z]+")[1]));
            }

            Collections.sort(tempList);

            int id = tempList.get((tempList.size() - 1));
            return "LEAV00" + ++id;
        }

    }

}
