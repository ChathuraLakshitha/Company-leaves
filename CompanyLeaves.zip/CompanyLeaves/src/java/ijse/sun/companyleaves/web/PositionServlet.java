package ijse.sun.companyleaves.web;

import ijse.sun.companyleaves.attributes.ApplicationAttribute;
import ijse.sun.companyleaves.common.dto.Department;
import ijse.sun.companyleaves.application.DepartmentDAO;
import ijse.sun.companyleaves.application.factory.DAOFactory;
import ijse.sun.companyleaves.application.factory.impl.DAOFactoryImpl;
import java.io.IOException;
import java.io.PrintWriter;
import java.math.BigDecimal;
import java.util.ArrayList;
import javax.json.Json;
import javax.json.JsonArrayBuilder;
import javax.json.JsonObjectBuilder;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

public class PositionServlet extends HttpServlet {

    @Override
    protected void doGet(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
        DAOFactory dAOFactory = null;
        PrintWriter out = null;
        try {
            dAOFactory = new DAOFactoryImpl(getServletContext());
            DepartmentDAO departmentDAO = dAOFactory.createDepartment();

            out = resp.getWriter();

            resp.setContentType("application/json");
            JsonObjectBuilder jsonSender = Json.createObjectBuilder();
            int position = Integer.parseInt(req.getParameter("sign-position-one"));

            switch (position) {
                case 1:
                    jsonSender.add("position", false);
                    String jsonString = jsonSender.build().toString();
                    out.print(jsonString);
                    out.close();
                    break;
                case 2:
                case 3:
                    jsonSender.add("position", true);
                    ArrayList<Department> departmentList = departmentDAO.getAllDepartments();

                    JsonArrayBuilder arrayBuilder = Json.createArrayBuilder();

                    for (Department department : departmentList) {
                        JsonObjectBuilder tempBuilder = Json.createObjectBuilder();
                        tempBuilder.add("id", department.getId());
                        tempBuilder.add("name", department.getName());
                        arrayBuilder.add(tempBuilder);
                    }
                    jsonSender.add("data", arrayBuilder);
                    String jsonString2 = jsonSender.build().toString();
                    out.print(jsonString2);
                    out.close();
                    break;
            }

        } finally {
            if (out != null) {
                out.close();
            }
        }

    }
}
