package ijse.sun.companyleaves.web;

import ijse.sun.companyleaves.service.factory.Service;
import ijse.sun.companyleaves.service.factory.impl.ServiceImpl;
import java.io.IOException;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

public class LogOutServlet extends HttpServlet{

    @Override
    protected void doGet(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
        Service service = new ServiceImpl(getServletContext());
        service.getSignService().logOut(req, resp);
    }
    
}
