package ijse.sun.companyleaves.web;

import ijse.sun.companyleaves.common.dto.Leave;
import ijse.sun.companyleaves.service.factory.Service;
import ijse.sun.companyleaves.service.factory.impl.ServiceImpl;
import java.io.IOException;
import java.io.PrintWriter;
import java.math.BigDecimal;
import javax.json.Json;
import javax.json.JsonObjectBuilder;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

public class AddLeaveServlet extends HttpServlet {
    
    @Override
    protected void doPost(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
        PrintWriter out = null;
        
        Service service = null;
        
        try {
            service = new ServiceImpl(getServletContext());
            
            Leave leave = service.getLeaveService().addLeave(req, resp);
            
            out = resp.getWriter();
            
            if (leave != null) {
                out.print("Add " + leave.getLeaveId() + " : " + leave.getDepartmentId() + " : " + leave.getEmptId());
            } else {
                
                resp.setContentType("application/json");
                JsonObjectBuilder jsonSender = Json.createObjectBuilder();
                jsonSender.add("status", false);
                jsonSender.add("reason", "");
                String js = jsonSender.build().toString();
                
                out.print(jsonSender);
            }
        } finally {
            if (out != null) {
                out.close();
            }
        }
    }
    
}
