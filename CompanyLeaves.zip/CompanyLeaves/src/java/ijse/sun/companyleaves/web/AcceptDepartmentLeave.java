package ijse.sun.companyleaves.web;

import ijse.sun.companyleaves.common.dto.Leave;
import ijse.sun.companyleaves.service.factory.Service;
import ijse.sun.companyleaves.service.factory.impl.ServiceImpl;
import java.io.IOException;
import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

public class AcceptDepartmentLeave extends HttpServlet {

    @Override
    protected void doGet(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
        Service service = new ServiceImpl(getServletContext());

        String leaveId = req.getParameter("leave-id");
        String leveId2 = req.getParameter("leave-id2");

        if (leaveId == null) {
            Leave leave = service.getLeaveService().accepteManagerLeave(leveId2, 1);
            RequestDispatcher requestDispatcher = req.getRequestDispatcher("./manager/manager.jsp");
            requestDispatcher.include(req, resp);
            System.err.println("leave delete");
        } else {
            Leave leave = service.getLeaveService().accepteManagerLeave(leaveId, 2);
            RequestDispatcher requestDispatcher = req.getRequestDispatcher("./manager/manager.jsp");
            requestDispatcher.include(req, resp);
            System.err.println("leave accept");
        }

//        Leave leave = service.getLeaveService().accepteManagerLeave(req.getParameter("leave-id"));
//
//        if (leave != null) {
//            RequestDispatcher requestDispatcher = req.getRequestDispatcher("./manager/manager.jsp");
//            requestDispatcher.include(req, resp);
//        }
    }

}
