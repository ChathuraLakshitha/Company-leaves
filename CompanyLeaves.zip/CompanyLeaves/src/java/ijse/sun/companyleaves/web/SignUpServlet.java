package ijse.sun.companyleaves.web;

import ijse.sun.companyleaves.common.dto.User;
import ijse.sun.companyleaves.service.factory.Service;
import ijse.sun.companyleaves.service.factory.impl.ServiceImpl;
import java.io.IOException;
import java.io.PrintWriter;
import java.math.BigDecimal;
import javax.json.Json;
import javax.json.JsonObjectBuilder;
import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

public class SignUpServlet extends HttpServlet {

    @Override
    protected void doPost(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
        Service service = new ServiceImpl(getServletContext());
        boolean signIn = service.getSignService().signIn(req, resp);
        if (!signIn) {
            RequestDispatcher dispatcher = req.getRequestDispatcher("index.jsp");
            int position = Integer.parseInt(req.getParameter("sign-position-one"));
            User user = new User();
            switch (position) {
                case 1:
                    user.setMail("Manager");
                    break;
                case 2:
                    user.setMail("Department head");
                    break;
            }
            req.setAttribute("User", user);
            dispatcher.include(req, resp);
//            resp.setContentType("application/json");
//            JsonObjectBuilder jsonSender = Json.createObjectBuilder();
//            jsonSender.add("status", false);
//            String js = jsonSender.build().toString();
//            PrintWriter out = resp.getWriter();
//            out.print(js);
//           out.close();
        }
        System.err.println(signIn);
    }

}
