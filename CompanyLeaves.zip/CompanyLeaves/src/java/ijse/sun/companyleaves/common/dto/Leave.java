package ijse.sun.companyleaves.common.dto;

import java.util.Date;

public class Leave {

    private String leaveId;
    private String departmentId;
    private String emptId;
    private int status;
    private String leaveDate;
    private String leaveType;
    private String reason;

    public Leave() {
    }

    public Leave(String leaveId, String departmentId, String emptId, int status, String leaveDate, String leaveType, String reason) {
        this.leaveId = leaveId;
        this.departmentId = departmentId;
        this.status = status;
        this.leaveDate = leaveDate;
        this.leaveType = leaveType;
        this.reason = reason;
        this.emptId = emptId;
    }

    /**
     * @return the leaveId
     */
    public String getLeaveId() {
        return leaveId;
    }

    /**
     * @param leaveId the leaveId to set
     */
    public void setLeaveId(String leaveId) {
        this.leaveId = leaveId;
    }

    /**
     * @return the departmentId
     */
    public String getDepartmentId() {
        return departmentId;
    }

    /**
     * @param departmentId the departmentId to set
     */
    public void setDepartmentId(String departmentId) {
        this.departmentId = departmentId;
    }

    /**
     * @return the status
     */
    public int getStatus() {
        return status;
    }

    /**
     * @param status the status to set
     */
    public void setStatus(int status) {
        this.status = status;
    }

    /**
     * @return the leaveDate
     */
    public String getLeaveDate() {
        return leaveDate;
    }

    /**
     * @param leaveDate the leaveDate to set
     */
    public void setLeaveDate(String leaveDate) {
        this.leaveDate = leaveDate;
    }

    /**
     * @return the leaveType
     */
    public String getLeaveType() {
        return leaveType;
    }

    /**
     * @param leaveType the leaveType to set
     */
    public void setLeaveType(String leaveType) {
        this.leaveType = leaveType;
    }

    /**
     * @return the reason
     */
    public String getReason() {
        return reason;
    }

    /**
     * @param reason the reason to set
     */
    public void setReason(String reason) {
        this.reason = reason;
    }

    /**
     * @return the emptId
     */
    public String getEmptId() {
        return emptId;
    }

    /**
     * @param emptId the emptId to set
     */
    public void setEmptId(String emptId) {
        this.emptId = emptId;
    }

}
