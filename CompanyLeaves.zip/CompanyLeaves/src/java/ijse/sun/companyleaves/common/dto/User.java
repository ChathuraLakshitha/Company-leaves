package ijse.sun.companyleaves.common.dto;

public class User {

    private String mail;
    private String password;
    private String path;
    private boolean isTrue;

    public User() {
    }

    public User(String mail, String password, String path, boolean isTrue) {
        this.mail = mail;
        this.password = password;
        this.path = path;
        this.isTrue = isTrue;
    }

    /**
     * @return the mail
     */
    public String getMail() {
        return mail;
    }

    /**
     * @param mail the mail to set
     */
    public void setMail(String mail) {
        this.mail = mail;
    }

    /**
     * @return the password
     */
    public String getPassword() {
        return password;
    }

    /**
     * @param password the password to set
     */
    public void setPassword(String password) {
        this.password = password;
    }

    /**
     * @return the path
     */
    public String getPath() {
        return path;
    }

    /**
     * @param path the path to set
     */
    public void setPath(String path) {
        this.path = path;
    }

    /**
     * @return the isTrue
     */
    public boolean isIsTrue() {
        return isTrue;
    }

    /**
     * @param isTrue the isTrue to set
     */
    public void setIsTrue(boolean isTrue) {
        this.isTrue = isTrue;
    }

}
