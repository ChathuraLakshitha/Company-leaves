package ijse.sun.companyleaves.common.dto;

public class Manager {

    private String headId;
    private String name;
    private String mail;
    private String gender;
    private String password;
    private int phoneNumber;

    public Manager() {
    }

    public Manager(String headId, String name, String mail, String gender, String password, int phoneNumber) {
        this.headId = headId;
        this.name = name;
        this.mail = mail;
        this.gender = gender;
        this.password = password;
        this.phoneNumber = phoneNumber;
    }

    /**
     * @return the headId
     */
    public String getHeadId() {
        return headId;
    }

    /**
     * @param headId the headId to set
     */
    public void setHeadId(String headId) {
        this.headId = headId;
    }

    /**
     * @return the name
     */
    public String getName() {
        return name;
    }

    /**
     * @param name the name to set
     */
    public void setName(String name) {
        this.name = name;
    }

    /**
     * @return the mail
     */
    public String getMail() {
        return mail;
    }

    /**
     * @param mail the mail to set
     */
    public void setMail(String mail) {
        this.mail = mail;
    }

    /**
     * @return the gender
     */
    public String getGender() {
        return gender;
    }

    /**
     * @param gender the gender to set
     */
    public void setGender(String gender) {
        this.gender = gender;
    }

    /**
     * @return the password
     */
    public String getPassword() {
        return password;
    }

    /**
     * @param password the password to set
     */
    public void setPassword(String password) {
        this.password = password;
    }

    /**
     * @return the phoneNumber
     */
    public int getPhoneNumber() {
        return phoneNumber;
    }

    /**
     * @param phoneNumber the phoneNumber to set
     */
    public void setPhoneNumber(int phoneNumber) {
        this.phoneNumber = phoneNumber;
    }

}
