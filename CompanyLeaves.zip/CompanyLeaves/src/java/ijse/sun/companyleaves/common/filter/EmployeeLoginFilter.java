package ijse.sun.companyleaves.common.filter;

import ijse.sun.companyleaves.common.dto.Employee;
import ijse.sun.companyleaves.idgenerator.IDGenerator;
import ijse.sun.companyleaves.wrappers.ServletContextWrapper;
import java.io.IOException;
import javax.servlet.Filter;
import javax.servlet.FilterChain;
import javax.servlet.FilterConfig;
import javax.servlet.ServletException;
import javax.servlet.ServletRequest;
import javax.servlet.ServletResponse;
import javax.servlet.http.HttpSession;

public class EmployeeLoginFilter implements Filter {

    @Override
    public void init(FilterConfig filterConfig) throws ServletException {

    }

    @Override
    public void doFilter(ServletRequest request, ServletResponse response, FilterChain chain) throws IOException, ServletException {
        String name = request.getParameter("login-name");
        String mail = request.getParameter("login-mail");
        String password = request.getParameter("login-password");
        String gender = request.getParameter("login-gender");
        int phoneNumber = Integer.parseInt(request.getParameter("login-phoneNumber"));
        String departmentID = request.getParameter("login-departmentID");

        IDGenerator iDGenerator = new IDGenerator(null);

        String empId = iDGenerator.createEmployeeId();

        Employee employee = new Employee(empId, departmentID, name, mail, password, phoneNumber, gender);
        
        
    }

    @Override
    public void destroy() {
    }

}
