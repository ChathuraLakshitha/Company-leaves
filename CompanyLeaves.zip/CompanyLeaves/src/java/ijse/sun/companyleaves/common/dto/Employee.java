package ijse.sun.companyleaves.common.dto;

public class Employee {

    private String empId;
    private String departmentID;
    private String name;
    private String mail;
    private String password;
    private String gender;
    private int phoneNumber;

    public Employee(String empDd, String departmentID, String name, String mail, String password, int phoneNumber, String gender) {
        this.empId = empDd;
        this.departmentID = departmentID;
        this.name = name;
        this.mail = mail;
        this.password = password;
        this.phoneNumber = phoneNumber;
        this.gender = gender;
    }

    public Employee() {
    }

    /**
     * @return the empDd
     */
    public String getEmpId() {
        return empId;
    }

    /**
     * @param empDd the empDd to set
     */
    public void setEmpId(String empDd) {
        this.empId = empDd;
    }

    /**
     * @return the departmentID
     */
    public String getDepartmentID() {
        return departmentID;
    }

    /**
     * @param departmentID the departmentID to set
     */
    public void setDepartmentID(String departmentID) {
        this.departmentID = departmentID;
    }

    /**
     * @return the name
     */
    public String getName() {
        return name;
    }

    /**
     * @param name the name to set
     */
    public void setName(String name) {
        this.name = name;
    }

    /**
     * @return the mail
     */
    public String getMail() {
        return mail;
    }

    /**
     * @param mail the mail to set
     */
    public void setMail(String mail) {
        this.mail = mail;
    }

    /**
     * @return the password
     */
    public String getPassword() {
        return password;
    }

    /**
     * @param password the password to set
     */
    public void setPassword(String password) {
        this.password = password;
    }

    /**
     * @return the phoneNumber
     */
    public int getPhoneNumber() {
        return phoneNumber;
    }

    /**
     * @param phoneNumber the phoneNumber to set
     */
    public void setPhoneNumber(int phoneNumber) {
        this.phoneNumber = phoneNumber;
    }

    /**
     * @return the gender
     */
    public String getGender() {
        return gender;
    }

    /**
     * @param gender the gender to set
     */
    public void setGender(String gender) {
        this.gender = gender;
    }
}
