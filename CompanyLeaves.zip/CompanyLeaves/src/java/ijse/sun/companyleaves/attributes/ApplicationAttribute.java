package ijse.sun.companyleaves.attributes;

public interface ApplicationAttribute {

    final static String EMPLOYEE_SCOPE = "EMPLOYEE_SCOPE";

    final static String DEPARTMENT_SCOPE = "DEPARTMENT_SCOPE";

    final static String DEPARTMENT_HEAD_SCOPE = "DEPARTMENT_HEAD_SCOPE";

    final static String MANAGER_SCOPE = "MANAGER_SCOPE";

    final static String LEAVE_SCOPE = "LEAVE_SCOPE";
}
