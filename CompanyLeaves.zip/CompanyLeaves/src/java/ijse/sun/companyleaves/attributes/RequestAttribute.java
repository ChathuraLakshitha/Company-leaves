package ijse.sun.companyleaves.attributes;

public interface RequestAttribute {

    final static String LOGER = "LOGER";
    
    final static String LOGER_MAIL = "LOGER_MAIL";
    
    final static String LOGER_PASSWORD = "LOGER_PASSWORD";
}
