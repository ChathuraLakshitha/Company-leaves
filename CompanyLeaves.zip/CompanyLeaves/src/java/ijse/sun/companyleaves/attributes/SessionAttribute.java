package ijse.sun.companyleaves.attributes;

public interface SessionAttribute {

    final static String USER_ID = "USER_ID";
}
