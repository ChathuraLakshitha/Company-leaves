package ijse.sun.companyleaves.wrappers;

import javax.servlet.ServletContext;
import javax.servlet.ServletContextEvent;
import javax.servlet.http.HttpSession;
import javax.servlet.http.HttpSessionEvent;
import org.apache.catalina.Session;

public class ServletContextWrapper extends ServletContextEvent {

    private ServletContext servletContext;

    public ServletContextWrapper(ServletContext source) {
        super(source);
    }
}
