package ijse.sun.companyleaves.listener;

import ijse.sun.companyleaves.attributes.ApplicationAttribute;
import ijse.sun.companyleaves.common.dto.Department;
import ijse.sun.companyleaves.common.dto.DepartmentHead;
import ijse.sun.companyleaves.common.dto.Employee;
import ijse.sun.companyleaves.common.dto.Leave;
import ijse.sun.companyleaves.common.dto.Manager;
import java.util.ArrayList;
import java.util.List;
import javax.servlet.ServletContextEvent;
import javax.servlet.ServletContextListener;

public class ContextListener implements ServletContextListener {

    @Override
    public void contextInitialized(ServletContextEvent sce) {

        Manager manager = new Manager();
        manager.setMail("M");
        manager.setPassword("M");

        Employee employee = new Employee("e001", "DHR001", "", "E1", "e", 0, "");
        Employee employee2 = new Employee("e002", "DHR001", "", "E2", "e", 0, "");
        Employee employee3 = new Employee("e003", "DIT003", "", "E3", "e", 0, "");
        Employee employee4 = new Employee("e004", "DIT003", "", "E4", "e", 0, "");
        Employee employee5 = new Employee("e005", "DF002", "", "E5", "e", 0, "");

        DepartmentHead departmentHead = new DepartmentHead("d1", "DHR001", "", "D1", "", "d", 0);
        //DepartmentHead departmentHead2 = new DepartmentHead("d2", "DF002", "", "D2", "", "d", 0);
        DepartmentHead departmentHead3 = new DepartmentHead("d3", "DIT003", "", "D3", "", "d", 0);

        Department department1 = new Department("DHR001", "HR(Human Resources)");
        Department department2 = new Department("DF002", "Finace");
        Department department3 = new Department("DIT003", "IT(Information Technology)");

        ArrayList<Department> departmentList = new ArrayList<Department>();

        departmentList.add(department1);
        departmentList.add(department2);
        departmentList.add(department3);

        sce.getServletContext().setAttribute(ApplicationAttribute.DEPARTMENT_SCOPE, departmentList);

        ArrayList<DepartmentHead> departmentHeadList = new ArrayList<DepartmentHead>();

        departmentHeadList.add(departmentHead);
       // departmentHeadList.add(departmentHead2);
        departmentHeadList.add(departmentHead3);

        sce.getServletContext().setAttribute(ApplicationAttribute.DEPARTMENT_HEAD_SCOPE, departmentHeadList);

        ArrayList<Employee> employeeList = new ArrayList<Employee>();

        employeeList.add(employee);
        employeeList.add(employee2);
        employeeList.add(employee3);
        employeeList.add(employee4);
        employeeList.add(employee5);

        sce.getServletContext().setAttribute(ApplicationAttribute.EMPLOYEE_SCOPE, employeeList);

        Manager manager1 = new Manager("", "", "M", "", "m", 0);

        //sce.getServletContext().setAttribute(ApplicationAttribute.MANAGER_SCOPE, manager1);

        ArrayList<Leave> leaveList = new ArrayList<Leave>();

        sce.getServletContext().setAttribute(ApplicationAttribute.LEAVE_SCOPE, leaveList);

        System.out.println("Start context . . . .");
    }

    @Override
    public void contextDestroyed(ServletContextEvent sce) {
        System.out.println("Context is destroyed ...");
    }

}
