package ijse.sun.companyleaves.temp;

import javax.servlet.ServletContext;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletRequestWrapper;
import javax.servlet.http.HttpSession;
import javax.servlet.http.HttpSessionEvent;

public class Temp extends HttpSessionEvent{
   
    public Temp(HttpSession source) {
        super(source);
        
    }
    
}
