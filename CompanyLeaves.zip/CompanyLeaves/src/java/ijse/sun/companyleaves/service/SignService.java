package ijse.sun.companyleaves.service;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

public interface SignService {
    
    void login(HttpServletRequest request,HttpServletResponse response);
    
    boolean signIn(HttpServletRequest request,HttpServletResponse response);
    
    void logOut(HttpServletRequest request,HttpServletResponse response);
}
