package ijse.sun.companyleaves.service.impl;

import ijse.sun.companyleaves.attributes.ApplicationAttribute;
import ijse.sun.companyleaves.attributes.SessionAttribute;
import ijse.sun.companyleaves.common.dto.DepartmentHead;
import ijse.sun.companyleaves.common.dto.Employee;
import ijse.sun.companyleaves.common.dto.Leave;
import ijse.sun.companyleaves.common.dto.Manager;
import ijse.sun.companyleaves.application.factory.DAOFactory;
import ijse.sun.companyleaves.application.factory.impl.DAOFactoryImpl;
import ijse.sun.companyleaves.idgenerator.IDGenerator;
import ijse.sun.companyleaves.service.LeaveService;
import java.util.ArrayList;
import java.util.Date;
import javax.servlet.ServletContext;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

public class LeaveServiceImpl implements LeaveService {

    private ServletContext servletContext;

    private DAOFactory dAOFactory;

    public LeaveServiceImpl(ServletContext servletContext) {
        this.servletContext = servletContext;
        dAOFactory = new DAOFactoryImpl(servletContext);
    }

    @Override
    public Leave addLeave(HttpServletRequest request, HttpServletResponse response) {
        String empId = (String) request.getSession().getAttribute(SessionAttribute.USER_ID);
        IDGenerator iDGenerator = new IDGenerator(servletContext);
        String leaveID = iDGenerator.createLeaveId();
        String deaprtmentID = null;

        DepartmentHead temp = dAOFactory.createDepartmentHeadDAO().searchDepartmentHead(empId);

        if (temp != null) {

            int status = 1;

            String reason = request.getParameter("leave-reason");

            String leaveType = request.getParameter("leave-type");

            String leaveDate = request.getParameter("leave-date");

            Leave leave = new Leave(leaveID, temp.getDepartmentId(), empId, status, leaveDate, leaveType, reason);

            ArrayList<Leave> leavesList = (ArrayList<Leave>) servletContext.getAttribute(ApplicationAttribute.LEAVE_SCOPE);

            leavesList.add(leave);

            servletContext.setAttribute(ApplicationAttribute.LEAVE_SCOPE, leavesList);

            return leave;

        } else {
            Employee employee = dAOFactory.createEmployeeDAO().searchEmployee(empId);

            int status = 0;

            String reason = request.getParameter("leave-reason");

            String leaveType = request.getParameter("leave-type");

            String leaveDate = request.getParameter("leave-date");

            Leave leave = new Leave(leaveID, employee.getDepartmentID(), empId, status, leaveDate, leaveType, reason);

            ArrayList<Leave> leavesList = (ArrayList<Leave>) servletContext.getAttribute(ApplicationAttribute.LEAVE_SCOPE);

            leavesList.add(leave);

            servletContext.setAttribute(ApplicationAttribute.LEAVE_SCOPE, leavesList);

            return leave;
        }
//        if (temp == null) {
//            Employee e = dAOFactory.createEmployeeDAO().searchEmployee(empId);
//            if (e != null) {
//                deaprtmentID = e.getDepartmentID();
//                return null;
//            }
//        } else {
//            deaprtmentID = temp.getDepartmentId();
//            return null;
//        }

//        int status = 0;
//
//        String reason = request.getParameter("leave-reason");
//
//        Leave leave = new Leave(leaveID, deaprtmentID, empId, status, new Date(), "", reason);
//
//        ArrayList<Leave> leavesList = (ArrayList<Leave>) servletContext.getAttribute(ApplicationAttribute.LEAVE_SCOPE);
//
//        leavesList.add(leave);
//
//        servletContext.setAttribute(ApplicationAttribute.LEAVE_SCOPE, leavesList);
//
//        return leave;
    }

    @Override
    public Leave acceptedDeaprtmentLeave(String leaveID, int status) {
        Leave leave = dAOFactory.createLeaveDAO().searchLeave(leaveID.trim());

        ArrayList<Leave> leavesList = dAOFactory.createLeaveDAO().getAllLeaves();
        Leave tempLeave = null;
        for (Leave leave1 : leavesList) {
            if (leave.getLeaveId().equals(leave1.getLeaveId())) {
                tempLeave = leave1;
            }
        }
        if (status == 2) {
            if (leavesList.remove(tempLeave)) {
                leave.setStatus(1);
                leavesList.add(leave);
                servletContext.removeAttribute(ApplicationAttribute.LEAVE_SCOPE);
                servletContext.setAttribute(ApplicationAttribute.LEAVE_SCOPE, leavesList);
                return tempLeave;
            } else {
                return null;
            }
        } else {
            if (leavesList.remove(tempLeave)) {
                servletContext.removeAttribute(ApplicationAttribute.LEAVE_SCOPE);
                servletContext.setAttribute(ApplicationAttribute.LEAVE_SCOPE, leavesList);
                return tempLeave;
            } else {
                return null;
            }
        }

    }

    @Override
    public Leave accepteManagerLeave(String leaveID,int status) {
        Leave leave = dAOFactory.createLeaveDAO().searchLeave(leaveID.trim());

        ArrayList<Leave> leavesList = dAOFactory.createLeaveDAO().getAllLeaves();
        Leave tempLeave = null;
        for (Leave leave1 : leavesList) {
            if (leave.getLeaveId().equals(leave1.getLeaveId())) {
                tempLeave = leave1;
            }
        }
        if (status == 2) {
            if (leavesList.remove(tempLeave)) {
                leave.setStatus(2);
                leavesList.add(tempLeave);
                servletContext.removeAttribute(ApplicationAttribute.LEAVE_SCOPE);
                servletContext.setAttribute(ApplicationAttribute.LEAVE_SCOPE, leavesList);
                return tempLeave;
            } else {
                return null;
            }
        } else {
            if (leavesList.remove(tempLeave)) {
                servletContext.removeAttribute(ApplicationAttribute.LEAVE_SCOPE);
                servletContext.setAttribute(ApplicationAttribute.LEAVE_SCOPE, leavesList);
                return tempLeave;
            } else {
                return null;
            }
        }
    }

}
