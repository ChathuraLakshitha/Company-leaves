package ijse.sun.companyleaves.service.factory.impl;

import ijse.sun.companyleaves.service.LeaveService;
import ijse.sun.companyleaves.service.SignService;
import ijse.sun.companyleaves.service.factory.Service;
import ijse.sun.companyleaves.service.impl.LeaveServiceImpl;
import ijse.sun.companyleaves.service.impl.SignServiceImpl;
import javax.servlet.ServletContext;

public class ServiceImpl implements Service {

    private ServletContext servletContext;

    public ServiceImpl(ServletContext servletContext) {
        this.servletContext = servletContext;
    }

    @Override
    public SignService getSignService() {
        SignService signService = new SignServiceImpl(servletContext);
        return signService;
    }

    @Override
    public LeaveService getLeaveService() {
        LeaveService leaveService = new LeaveServiceImpl(servletContext);
        return leaveService;
    }

}
