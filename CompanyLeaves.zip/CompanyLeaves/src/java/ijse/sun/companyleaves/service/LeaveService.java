package ijse.sun.companyleaves.service;

import ijse.sun.companyleaves.common.dto.Leave;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

public interface LeaveService {

    Leave addLeave(HttpServletRequest request, HttpServletResponse response);

    Leave acceptedDeaprtmentLeave(String leaveID,int status);

    Leave accepteManagerLeave(String leaveID ,int status);
}
