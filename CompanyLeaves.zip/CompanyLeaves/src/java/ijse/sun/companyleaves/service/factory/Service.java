package ijse.sun.companyleaves.service.factory;

import ijse.sun.companyleaves.service.LeaveService;
import ijse.sun.companyleaves.service.SignService;

public interface Service {

    SignService getSignService();
    
    LeaveService getLeaveService();
}
