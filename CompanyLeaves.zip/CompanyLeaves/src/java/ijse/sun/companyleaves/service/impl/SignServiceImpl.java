package ijse.sun.companyleaves.service.impl;

import ijse.sun.companyleaves.attributes.ApplicationAttribute;
import ijse.sun.companyleaves.attributes.RequestAttribute;
import ijse.sun.companyleaves.attributes.SessionAttribute;
import ijse.sun.companyleaves.common.dto.DepartmentHead;
import ijse.sun.companyleaves.common.dto.Employee;
import ijse.sun.companyleaves.common.dto.Manager;
import ijse.sun.companyleaves.common.dto.User;
import ijse.sun.companyleaves.application.factory.DAOFactory;
import ijse.sun.companyleaves.application.factory.impl.DAOFactoryImpl;
import ijse.sun.companyleaves.idgenerator.IDGenerator;
import ijse.sun.companyleaves.service.SignService;
import java.io.IOException;
import java.util.ArrayList;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.servlet.RequestDispatcher;
import javax.servlet.ServletContext;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

public class SignServiceImpl implements SignService {

    private ServletContext servletContext;
    DAOFactory dAOFactory;

    public SignServiceImpl(ServletContext servletContext) {
        this.servletContext = servletContext;
        dAOFactory = new DAOFactoryImpl(servletContext);
    }

    @Override
    public void login(HttpServletRequest request, HttpServletResponse response) {
        try {

            String mail = request.getParameter("login-mail");
            String password = request.getParameter("login-password");

            Manager manager = (Manager) servletContext.getAttribute(ApplicationAttribute.MANAGER_SCOPE);
            DepartmentHead departmentHead = dAOFactory.createDepartmentHeadDAO().searchDepartHeatToLogin(mail);
            Employee employee = dAOFactory.createEmployeeDAO().searchEmployeeToLogin(mail);

            RequestDispatcher requestDispatcher2 = request.getRequestDispatcher("signPage.jsp");
            if (manager != null) {
                if (manager.getMail().equals(mail)) {
                    if (manager.getPassword().equals(password)) {
                        RequestDispatcher requestDispatcher = request.getRequestDispatcher("./manager/manager.jsp");
                        request.getSession().setAttribute(SessionAttribute.USER_ID, manager.getHeadId());
                        requestDispatcher.forward(request, response);
                    } else {
                        User u = new User();
                        u.setMail(mail);
                        u.setPassword(password);
                        u.setIsTrue(true);
                        u.setPath("./image/correctLoger.jpg");
                        request.setAttribute("User", u);
                        requestDispatcher2.forward(request, response);
                    }
                }
            }
            if (departmentHead != null) {
                if (departmentHead.getMail().equals(mail) && departmentHead.getPassword().equals(password)) {
                    RequestDispatcher requestDispatcher = request.getRequestDispatcher("./departHead/depart.jsp");
                    request.getSession().setAttribute(SessionAttribute.USER_ID, departmentHead.getHeadId());
                    requestDispatcher.include(request, response);
                } else {
                    User u = new User();
                    u.setMail(mail);
                    u.setPassword(password);
                    u.setIsTrue(true);
                    u.setPath("./image/correctLoger.jpg");
                    request.setAttribute("User", u);
                    requestDispatcher2.include(request, response);
                }
            } else if (employee != null) {
                if (employee.getMail().equals(mail) && employee.getPassword().equals(password)) {
                    RequestDispatcher requestDispatcher = request.getRequestDispatcher("./employee/employee.jsp");
                    request.getSession().setAttribute(SessionAttribute.USER_ID, employee.getEmpId());
                    requestDispatcher.forward(request, response);
                } else {
                    User u = new User();
                    u.setMail(mail);
                    u.setIsTrue(true);
                    u.setPassword(password);
                    u.setPath("./image/correctLoger.jpg");
                    request.setAttribute("User", u);
                    requestDispatcher2.include(request, response);
                }
            } else {
                User u = new User();
                u.setMail(mail);
                u.setIsTrue(false);
                u.setPassword(password);
                u.setPath("./image/avatar-default.jpg");
                request.setAttribute("User", u);
                requestDispatcher2.include(request, response);
            }
        } catch (ServletException ex) {
            Logger.getLogger(SignServiceImpl.class.getName()).log(Level.SEVERE, null, ex);
        } catch (IOException ex) {
            Logger.getLogger(SignServiceImpl.class.getName()).log(Level.SEVERE, null, ex);
        }
    }

    @Override
    public boolean signIn(HttpServletRequest request, HttpServletResponse response) {
        try {
            int signPossitionOne = Integer.parseInt(request.getParameter("sign-position-one"));
            String departId = request.getParameter("sign-position-two");
            switch (signPossitionOne) {
                case 1:
                    Manager manager = dAOFactory.createManagerDAO().getManager();
                    if (manager != null) {
                        return false;
                    } else {
                        dAOFactory.createManagerDAO().addManager(request);
                        RequestDispatcher dispatcher = request.getRequestDispatcher("./manager/manager.jsp");
                        dispatcher.forward(request, response);
                        return true;
                    }
                case 2:
                    DepartmentHead departmentHead = dAOFactory.createDepartmentHeadDAO().searchDeaparByDepartmnet(departId);
                    if (departmentHead == null) {
                        DepartmentHead departmentHead1 = dAOFactory.createDepartmentHeadDAO().addDepartmentHead(request);
                        if (departmentHead1 == null) {
                            return false;
                        } else {
                            RequestDispatcher dispatcher = request.getRequestDispatcher("./departHead/depart.jsp");
                            dispatcher.forward(request, response);
                            return true;
                        }

                    } else {
                        return false;
                    }
                case 3:
                    Employee employee = dAOFactory.createEmployeeDAO().addEmployee(request);
                    if (employee != null) {
                        RequestDispatcher dispatcher = request.getRequestDispatcher("./employee/employee.jsp");
                        dispatcher.forward(request, response);
                        return true;
                    } else {
                        return false;
                    }
            }

        } catch (ServletException ex) {
            Logger.getLogger(SignServiceImpl.class.getName()).log(Level.SEVERE, null, ex);
        } catch (IOException ex) {
            Logger.getLogger(SignServiceImpl.class.getName()).log(Level.SEVERE, null, ex);
        }

        return false;
    }

    @Override
    public void logOut(HttpServletRequest request, HttpServletResponse response) {
        try {
            request.getSession().removeAttribute(SessionAttribute.USER_ID);
            RequestDispatcher dispatcher = request.getRequestDispatcher("index.jsp");
            dispatcher.forward(request, response);
        } catch (ServletException ex) {
            Logger.getLogger(SignServiceImpl.class.getName()).log(Level.SEVERE, null, ex);
        } catch (IOException ex) {
            Logger.getLogger(SignServiceImpl.class.getName()).log(Level.SEVERE, null, ex);
        }
    }

}
